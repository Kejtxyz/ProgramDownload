package zajecia1.samochodDoGierki;

//public class Controller {
//
//    // move . silknik
//    for(int i = 0; i.=0; i++){
//        if(pressKey Enter){
//            move++;
//        }else (pressKey spacja)
//        move--;
//    }
//}
