package Payment;
// enum
public enum Paymentmetody {
    CREDITCARD,PAYU,
}
