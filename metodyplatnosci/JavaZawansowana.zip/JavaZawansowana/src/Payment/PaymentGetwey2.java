package Payment;

public class PaymentGetwey2 {
}
