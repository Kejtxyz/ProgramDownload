package ZooKolekcje;

public class Human {

}
