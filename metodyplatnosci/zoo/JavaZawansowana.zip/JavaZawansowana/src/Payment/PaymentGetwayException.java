package Payment;

public class PaymentGetwayException extends RuntimeException{

}
