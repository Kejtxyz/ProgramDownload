package Interface;

public class Motorowka {
    void plyn
}
