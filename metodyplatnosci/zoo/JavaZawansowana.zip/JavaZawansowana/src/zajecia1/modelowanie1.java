package zajecia1;

public class modelowanie1 {



}
