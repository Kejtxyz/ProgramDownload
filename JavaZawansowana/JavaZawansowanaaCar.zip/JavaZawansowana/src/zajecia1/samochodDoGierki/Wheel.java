package zajecia1.samochodDoGierki;

public class Wheel {

}
